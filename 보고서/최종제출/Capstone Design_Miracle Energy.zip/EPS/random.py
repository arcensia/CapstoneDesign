from ast import Str
import random


one = ["Lee","Kim", "choi", "See", "Su"]
two = []
print(one[1])


print(one[random.randrange(0,4,1)])

for i in range(0,10,1):
    intxt = Str(i)+one


